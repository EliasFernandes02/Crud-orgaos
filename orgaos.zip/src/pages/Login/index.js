import React from 'react';

function Login(){
    return (
        <>
            <h4>Login</h4>
            <hr />
            
        </>
    );
}

export default Login;