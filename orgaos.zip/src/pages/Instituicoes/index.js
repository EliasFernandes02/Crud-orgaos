import React from 'react';

function Instituicoes(){
    return (
        <>
            <h4>Instituções</h4>
            <hr />
            
        </>
    );
}

export default Instituicoes;