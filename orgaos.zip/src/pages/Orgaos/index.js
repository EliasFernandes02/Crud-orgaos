import React from 'react';

function Orgaos(){
    return (
        <>
            <h4>Órgãos</h4>
            <hr />
            
        </>
    );
}

export default Orgaos;