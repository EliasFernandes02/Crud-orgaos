import React from 'react';

function Doadores(){
    return (
        <>
            <h4>Doadores</h4>
            <hr />
            
        </>
    );
}

export default Doadores;