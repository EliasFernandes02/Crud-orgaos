import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Painel from "./pages/Painel";
import Doadores from "./pages/Doadores";
import Instituicoes from "./pages/Instituicoes";
import Orgaos from "./pages/Orgaos";
import Usuarios from "./pages/Usuarios";
import UsuarioForm from "./pages/Usuarios/Form";
import Login from "./pages/Login";
import DefaultLayout from "./layouts/DefaultLayout";

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <DefaultLayout colorBarraMenu="#333" colorText="white">
          <Routes>
            <Route path="/" element={<Painel />} exact />
            <Route path="doadores" element={<Doadores />} />
            <Route path="instituicoes" element={<Instituicoes />} />
            <Route path="orgaos" element={<Orgaos />} />
            <Route path="usuarios" element={<Usuarios />} />
            <Route path="usuarios/novo" element={<UsuarioForm />} />
            <Route path="usuarios/editar/:id" element={<UsuarioForm />} />
            <Route path="login" element={<Login />} />
          </Routes>
        </DefaultLayout>
      </BrowserRouter>
      
    </div>
  );
}

export default App;
